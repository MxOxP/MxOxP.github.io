# TestScormUADO

Test de construcción de paquete scorm incluyendo funciones con API